using System;
using System.Threading;

namespace Examples
{
    class Demo3DProgram
    {
        static void Main()
        {
            var engine = new Simple3DEngine();

            var cube = new Cube { Position = new Vector3(0, 0, 0) };
            var sphere = new Sphere { Position = new Vector3(3, 0, 0) };

            engine.AddEntity(cube);
            engine.AddEntity(sphere);

            float angle = 0;

            while(true)
            {
                angle += 0.01f;
                cube.Rotation = new Vector3(0, angle, 0);
                sphere.Rotation = new Vector3(0, -angle, 0);

                engine.Render();

                Thread.Sleep(100);
            }
        }
    }
}
