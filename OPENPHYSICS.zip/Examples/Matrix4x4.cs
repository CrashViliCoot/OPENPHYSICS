using System;

namespace Examples
{
    public struct Matrix4x4
    {
        public float[,] M;

        public Matrix4x4(bool identity = false)
        {
            M = new float[4,4];
            if (identity)
            {
                M[0,0] = 1; M[1,1] = 1; M[2,2] = 1; M[3,3] = 1;
            }
        }

        public static Matrix4x4 Identity => new Matrix4x4(true);

        public static Matrix4x4 CreateRotationY(float angle)
        {
            var m = Identity;
            m.M[0,0] = MathF.Cos(angle);
            m.M[0,2] = MathF.Sin(angle);
            m.M[2,0] = -MathF.Sin(angle);
            m.M[2,2] = MathF.Cos(angle);
            return m;
        }

        public static Matrix4x4 CreateTranslation(Vector3 pos)
        {
            var m = Identity;
            m.M[3,0] = pos.X;
            m.M[3,1] = pos.Y;
            m.M[3,2] = pos.Z;
            return m;
        }

        public static Vector3 Transform(Vector3 v, Matrix4x4 m)
        {
            float x = v.X * m.M[0,0] + v.Y * m.M[1,0] + v.Z * m.M[2,0] + m.M[3,0];
            float y = v.X * m.M[0,1] + v.Y * m.M[1,1] + v.Z * m.M[2,1] + m.M[3,1];
            float z = v.X * m.M[0,2] + v.Y * m.M[1,2] + v.Z * m.M[2,2] + m.M[3,2];
            return new Vector3(x, y, z);
        }
    }
}
