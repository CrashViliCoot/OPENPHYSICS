using System;
using System.Collections.Generic;

namespace Examples
{
    public abstract class Entity3D
    {
        public Vector3 Position;
        public Vector3 Rotation;
        public Vector3 Scale = new Vector3(1,1,1);

        public abstract void Draw();
    }

    public class Cube : Entity3D
    {
        public override void Draw()
        {
            Console.WriteLine($"Cube at {Position.X:F2}, {Position.Y:F2}, {Position.Z:F2}");
        }
    }

    public class Sphere : Entity3D
    {
        public override void Draw()
        {
            Console.WriteLine($"Sphere at {Position.X:F2}, {Position.Y:F2}, {Position.Z:F2}");
        }
    }

    public class Simple3DEngine
    {
        public List<Entity3D> Entities = new();

        public void AddEntity(Entity3D entity) => Entities.Add(entity);

        public void Render()
        {
            Console.Clear();
            Console.WriteLine("=== 3D Scene ===");
            foreach(var e in Entities)
            {
                e.Draw();
            }
        }
    }
}
