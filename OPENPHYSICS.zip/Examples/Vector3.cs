using System;

namespace Examples
{
    public struct Vector3
    {
        public float X, Y, Z;

        public Vector3(float x, float y, float z)
        {
            X = x; Y = y; Z = z;
        }

        public static Vector3 operator +(Vector3 a, Vector3 b)
            => new Vector3(a.X + b.X, a.Y + b.Y, a.Z + b.Z);

        public static Vector3 operator -(Vector3 a, Vector3 b)
            => new Vector3(a.X - b.X, a.Y - b.Y, a.Z - b.Z);

        public static Vector3 operator *(Vector3 v, float scalar)
            => new Vector3(v.X * scalar, v.Y * scalar, v.Z * scalar);

        public static Vector3 operator /(Vector3 v, float scalar)
            => new Vector3(v.X / scalar, v.Y / scalar, v.Z / scalar);

        public float Length() => MathF.Sqrt(X * X + Y * Y + Z * Z);

        public Vector3 Normalized()
        {
            float len = Length();
            return len > 0 ? this / len : new Vector3(0, 0, 0);
        }
    }
}
