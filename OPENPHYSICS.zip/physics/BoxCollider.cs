namespace Physics
{
    public class BoxCollider
    {
        public RigidBody Body;
        public Vector2 Size;

        public BoxCollider(RigidBody body, Vector2 size)
        {
            Body = body;
            Size = size;
        }

        public (Vector2 min, Vector2 max) GetAABB()
        {
            var half = Size * 0.5f;
            var center = Body.Position;
            return (center - half, center + half);
        }

        public bool Intersects(BoxCollider other)
        {
            var (amin, amax) = GetAABB();
            var (bmin, bmax) = other.GetAABB();
            return !(amax.X < bmin.X || amin.X > bmax.X || amax.Y < bmin.Y || amin.Y > bmax.Y);
        }
    }
}
