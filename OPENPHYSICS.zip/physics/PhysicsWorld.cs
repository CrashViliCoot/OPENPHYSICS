using System.Collections.Generic;

namespace Physics
{
    public class PhysicsWorld
    {
        public List<RigidBody> Bodies = new();
        public Vector2 Gravity = new(0, 9.81f);

        public void AddBody(RigidBody body) => Bodies.Add(body);

        public void Step(float dt)
        {
            foreach (var body in Bodies)
            {
                if (body.IsStatic) continue;

                body.ApplyForce(Gravity * body.Mass);
                body.Position += body.Velocity * dt;
            }

            for (int i = 0; i < Bodies.Count; i++)
            for (int j = i + 1; j < Bodies.Count; j++)
            {
                var a = Bodies[i];
                var b = Bodies[j];

                if (a.Collider.Intersects(b.Collider))
                {
                    ResolveCollision(a, b);
                }
            }
        }

        void ResolveCollision(RigidBody a, RigidBody b)
        {
            if (a.IsStatic && b.IsStatic) return;

            var mtv = new Vector2(0, -0.1f);
            if (!a.IsStatic) a.Position += mtv;
            if (!b.IsStatic) b.Position -= mtv;

            if (!a.IsStatic) a.Velocity = new Vector2(a.Velocity.X, 0);
            if (!b.IsStatic) b.Velocity = new Vector2(b.Velocity.X, 0);
        }
    }
}
