namespace Physics
{
    public class RigidBody
    {
        public Vector2 Position;
        public Vector2 Velocity;
        public float Mass;
        public bool IsStatic;
        public BoxCollider Collider;

        public RigidBody(Vector2 position, Vector2 size, float mass, bool isStatic = false)
        {
            Position = position;
            Mass = mass;
            IsStatic = isStatic;
            Collider = new BoxCollider(this, size);
        }

        public void ApplyForce(Vector2 force)
        {
            if (IsStatic) return;
            Velocity += force / Mass;
        }
    }
}
