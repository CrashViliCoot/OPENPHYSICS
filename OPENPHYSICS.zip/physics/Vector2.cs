using System;

namespace Physics
{
    public struct Vector2
    {
        public float X, Y;

        public Vector2(float x, float y) { X = x; Y = y; }

        public static Vector2 Zero => new(0, 0);
        public static Vector2 Down => new(0, 1);

        public float Length() => MathF.Sqrt(X * X + Y * Y);
        public Vector2 Normalized() => this / Length();

        public static Vector2 operator +(Vector2 a, Vector2 b) => new(a.X + b.X, a.Y + b.Y);
        public static Vector2 operator -(Vector2 a, Vector2 b) => new(a.X - b.X, a.Y - b.Y);
        public static Vector2 operator *(Vector2 v, float scalar) => new(v.X * scalar, v.Y * scalar);
        public static Vector2 operator /(Vector2 v, float scalar) => new(v.X / scalar, v.Y / scalar);
    }
}
