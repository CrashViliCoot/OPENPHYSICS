﻿using System;
using System.Threading;
using Physics;

class Program
{
    static void Main()
    {
        var world = new PhysicsWorld();

        var ground = new RigidBody(new Vector2(0, 10), new Vector2(20, 1), mass: 0, isStatic: true);
        var box = new RigidBody(new Vector2(0, 0), new Vector2(1, 1), mass: 1f);

        world.AddBody(ground);
        world.AddBody(box);

        const float dt = 0.016f; // ~60fps

        for (int frame = 0; frame < 300; frame++)
        {
            world.Step(dt);

            Console.Clear();
            Console.WriteLine($"Frame {frame}");
            Console.WriteLine($"Box Pos: {box.Position.X:F2}, {box.Position.Y:F2}");
            Thread.Sleep(16);
        }
    }
}
